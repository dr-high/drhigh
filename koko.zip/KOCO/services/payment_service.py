# Example custom payment service
async def process_payment(user_id, amount):
    # Implement payment logic here
    return True
